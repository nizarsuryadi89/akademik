<?php	
	$username       = $_SESSION['username'];
    $nama           = $_SESSION['nama'];
    $semester       = $_SESSION['semester'];
    $tahun          = $_SESSION['tahun'];
    $userkd         = $_SESSION['id'];
?>