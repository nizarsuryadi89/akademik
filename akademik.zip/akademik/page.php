 <hr>
<div class="row">
    <div class="col-lg-12">
        <ol class="breadcrumb">
          <li><a href="?page=dashboard"><i class="icon-dashborad">Dashboard</a></i></li>
          <li><a href="?page=<?php echo"$_GET[page]";?> "">
          		<i class="icon-dashborad"><?php echo"$_GET[page]";?></a></i>
          </li>
          
        </ol>
      </div>
  </div>
