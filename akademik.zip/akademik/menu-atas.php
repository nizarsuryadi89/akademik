<ul class="nav ace-nav">
	<li class="light-blue dropdown-modal">
		<a data-toggle="dropdown" href="#" class="dropdown-toggle">
			<img class="nav-user-photo" src='../assets/images/smk.png' alt="Jason's Photo" />
			<span class="user-info">
				<small>Selamat Datang,</small>
				Admin
			</span>

			<i class="ace-icon fa fa-caret-down"></i>
		</a>

		<ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
			<li>
				<a href="?modul=info_skul">
					<i class="ace-icon fa fa-cog"></i>
					Settings
				</a>
			</li>

			<li>
				<a href="?modul=info_skul">
					<i class="ace-icon fa fa-user"></i>
					Profile
				</a>
			</li>

			<li class="divider"></li>

			<li>
				<a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Log Out</a>
			</li>
		</ul>
	</li>
</ul>