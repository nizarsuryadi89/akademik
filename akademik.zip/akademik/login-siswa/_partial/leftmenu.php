

      <ul class="nav nav-list">
     
       <li><a href="?page=Dashboard"><i class="fa fa-dashboard"></i> <span>Dashboard</span> </a></li>
    
          <li class="">
           <a href="#" class="dropdown-toggle">
            <i class="glyphicon glyphicon-hdd"></i> <span>Informasi</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="submenu">
            <li>
              <a href="?page=Edit Informasi Pribadi"><i class="fa fa-circle-o"></i> Informasi Pribadi
                <span class="pull-right-container"></span>
              </a>
            </li>
             <li>
              <a href="?page=Kegiatan Yang Diikuti"><i class="fa fa-circle-o"></i> Kegiatan</a>
              
            </li>
            <li>
              <a href="?page=Point Siswa"><i class="fa fa-circle-o"></i> Point Siswa</a>
              
            </li>
             <li>
              <a href="?page=Pelajaran"><i class="fa fa-circle-o"></i> Pelajaran</a>
              
            </li>
             
            
            
          </ul>
        </li>
        <li class="">
           <a href="#" class="dropdown-toggle">
            <i class="glyphicon glyphicon-hdd"></i> <span>Transkrip Nilai</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="submenu">
            <li>
              <a href="?page=Transkrip Nilai&sms=1"><i class="fa fa-circle-o"></i> Semester 1
                <span class="pull-right-container"></span>
              </a>
            </li>  
            <li>
              <a href="?page=Transkrip Nilai&sms=2"><i class="fa fa-circle-o"></i> Semester 2
                <span class="pull-right-container"></span>
              </a>
            </li>          
            <li>
              <a href="?page=Transkrip Nilai&sms=3"><i class="fa fa-circle-o"></i> Semester 3
                <span class="pull-right-container"></span>
              </a>
            </li> 
            <li>
              <a href="?page=Transkrip Nilai&sms=4"><i class="fa fa-circle-o"></i> Semester 4
                <span class="pull-right-container"></span>
              </a>
            </li> 
            <li>
              <a href="?page=Transkrip Nilai&sms=5"><i class="fa fa-circle-o"></i> Semester 5
                <span class="pull-right-container"></span>
              </a>
            </li> 
            <li>
              <a href="?page=Transkrip Nilai&sms=6"><i class="fa fa-circle-o"></i> UAS/UASBN
                <span class="pull-right-container"></span>
              </a>
            </li> 
            <li>
              <a href="?page=Transkrip Nilai&sms=6"><i class="fa fa-circle-o"></i> UJIKOM
                <span class="pull-right-container"></span>
              </a>
            </li>     
            <li>
              <a href="?page=Transkrip Nilai&sms=6"><i class="fa fa-circle-o"></i> UN
                <span class="pull-right-container"></span>
              </a>
            </li>    
          </ul>
        </li>
      
           <li class="">
              <a href="#" class="dropdown-toggle">
                <i class="fa fa-share"></i> <span>Setting </span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                  <ul class="submenu">
                      <li><a href="?page=Ganti Password"><i class="fa fa-circle-o"></i> Ganti Password</a></li>
                     
                      
                  </ul>
                </span>
              </a>
              
            </li>
            <!--
        <li class="header">Artikel</li>
           <li class="treeview">
              <a href="#">
                <i class="fa fa-share"></i> <span>Artikel </span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                   <ul class="treeview-menu">
                      <li><a href="?page=Data Artikel"><i class="fa fa-circle-o"></i> Data Artikel</a></li>               
                  </ul>
                </span>
              </a>
              
            </li> -->
          
          <li><a href="logout.php"><i class="fa fa-circle-o"></i> Logout</a></li> 
          </ul>

      
     
    <!-- /.sidebar -->