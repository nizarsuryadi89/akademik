<?php
	session_start();
	session_destroy();
	header("location: http://smknutasikmalaya.sch.id");
?>
