<div class="panel panel-default" align='center'>
	<div class="panel-body" align="center">
		<div class="text-center" id="cover_utama">
		<br>
		<br>
		<br>
		<img src='../img/smk.png' width='30%'>
		<br>
		<br>
		<br>
	
		<br>
		<br>
		<h3>TRANSKRIP NILAI  SISWA</h3>
		<h3>SEKOLAH MENENGAH KEJURUAN</h3>
		<h3>NAHDLATUL ULAMA KOTA TASIKMALAYA</h3></h3><br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<div style="width:25%; float:left;">&nbsp;</div>
		<div style="width:25%; float:left;">&nbsp;</div>
		<div style="width:100%; float:left; padding:7px;">NAMA : <br><br><br>
		<div style="border:#000000 1px  float:center; padding:7px;"><h4><?php echo strtoupper(@$siswa[siswa_nama]); ?></h4></div>
		</div>
		<br>
		<br>
		<br>
		<br>
		<br>
		<div style="width:47%; float:left; padding:7px;">	</div>
			

		<div style="width:25%; float:left;">&nbsp;</div>
		<br>
		<br>
		<br>
		<br>
		<br>
		<div style="width:25%; float:left;">&nbsp;</div>
		<div style="width:100%; float:left; padding:7px;">NISN / NIS: <br>
		<div style="border:#000000 1px  float:center; padding:7px;"><h4><?php echo strtoupper(@$siswa[siswa_nisn]); ?></h4> / <h4><?php echo strtoupper(@$siswa[siswa_nis]); ?></h4></div>
		</div>
		<div style="width:25%; float:left;">&nbsp;</div>
		<div style="width:25%; float:left;">&nbsp;</div>
		<div style="width:47%; float:left; padding:7px;">	</div>
				

		<div style="width:25%; float:left;">&nbsp;</div>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		
		
		<br>
		<br>
		<br>
		
		<h3>KEMENTERIAN PENDIDIKAN DAN KEBUDAYAAN<br>REPUBLIK INDONESIA</h3>
		
		</div>
</div>
</div>