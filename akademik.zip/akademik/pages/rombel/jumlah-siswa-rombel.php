<?php
	$query=$con->query("select * from tbl_pesertarombel where rombel_id=$ ")
?>